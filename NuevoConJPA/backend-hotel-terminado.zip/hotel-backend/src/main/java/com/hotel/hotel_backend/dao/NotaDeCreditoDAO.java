package com.hotel.hotel_backend.dao;

import com.hotel.hotel_backend.domain.NotaDeCredito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotaDeCreditoDAO extends JpaRepository<NotaDeCredito, Integer> {
}
